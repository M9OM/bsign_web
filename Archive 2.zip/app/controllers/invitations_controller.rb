# frozen_string_literal: true

class InvitationsController < Devise::PasswordsController
end
