# frozen_string_literal: true

class PwaController < ActionController::Base
end
